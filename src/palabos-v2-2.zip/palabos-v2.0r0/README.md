# Palabos

Palabos is an open-source CFD solver based on the [lattice Boltzmann](http://www.palabos.org/software/lattice-boltzmann-method) 
method. 
On this page you can download the code, [access examples](http://www.palabos.org/gallery/overview) and resources, 
and [interact with the user base](http://www.palabos.org/forum/index.php).
